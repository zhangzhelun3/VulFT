import os
import json
import torch
import logging
import pandas as pd
import numpy as np
from tqdm import tqdm
from transformers import AutoTokenizer, AutoModelForCausalLM
from peft import PeftModel
import Levenshtein
import re

# =========================================================
# 📦 导入评估库
# =========================================================
HAS_CODEBLEU = False
HAS_SACREBLEU = False
try:
    from codebleu import calc_codebleu

    HAS_CODEBLEU = True
except ImportError:
    print("⚠️ 'codebleu' not found. Skipping CodeBLEU.")
try:
    from sacrebleu.metrics import BLEU

    HAS_SACREBLEU = True
except ImportError:
    print("⚠️ 'sacrebleu' not found. Skipping SacreBLEU.")

# =========================================================
# ⚙️ 配置区域
# =========================================================
BASE_MODEL_PATH = "/home/zhangzl/projects/LLM_fix/models/Qwen2.5-Coder-7B-Instruct/"
ADAPTER_PATH = "/home/zhangzl/projects/LLM_fix/outputs/Qwen2.5-7B-Fix"
TEST_DATA_PATH = "/home/zhangzl/projects/CodeLlama/data/my_data/data_v3/test.csv"
RESULT_DIR = "/home/zhangzl/projects/LLM_fix/outputs/qwen_result/"
os.makedirs(RESULT_DIR, exist_ok=True)

MAX_NEW_TOKENS = 1024
BATCH_SIZE = 8
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


def load_model_and_tokenizer():
    logger.info("🚀 Loading Tokenizer...")
    tokenizer = AutoTokenizer.from_pretrained(BASE_MODEL_PATH, trust_remote_code=True)
    SPECIAL_TOKENS = ["<MODIFY_HERE>", "</MODIFY_HERE>", "<S2SV_ModStart>", "<S2SV_ModEnd>"]
    tokenizer.add_tokens(SPECIAL_TOKENS)
    tokenizer.padding_side = "left"
    if tokenizer.pad_token is None: tokenizer.pad_token = tokenizer.eos_token

    logger.info("🚀 Loading Base Model (BF16)...")
    try:
        model = AutoModelForCausalLM.from_pretrained(
            BASE_MODEL_PATH, torch_dtype=torch.bfloat16, trust_remote_code=True, device_map="auto",
            attn_implementation="flash_attention_2"
        )
    except:
        model = AutoModelForCausalLM.from_pretrained(
            BASE_MODEL_PATH, torch_dtype=torch.bfloat16, trust_remote_code=True, device_map="auto"
        )
    model.resize_token_embeddings(len(tokenizer))
    logger.info(f"🚀 Loading LoRA Adapter...")
    model = PeftModel.from_pretrained(model, ADAPTER_PATH)
    model.eval()
    return model, tokenizer


def build_prompt(row, tokenizer):
    sys_msg = "You are a helpful coding assistant specialized in fixing bugs. Output ONLY the fixed code wrapped in <S2SV_ModStart> and <S2SV_ModEnd> tags. Do not explain."
    user_msg = f"The following code contains bugs:\n{row['new_source']}\n\nRepair the bugs."
    messages = [{"role": "system", "content": sys_msg}, {"role": "user", "content": user_msg}]
    return tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)


# 【核心功能】正则提取器
def extract_code_content(text):
    pattern = r"<S2SV_ModStart>(.*?)<S2SV_ModEnd>"
    matches = re.findall(pattern, text, re.DOTALL)
    if matches:
        return " ".join(matches).strip()
    return text.strip()


def normalize_code_loose(text):
    if not isinstance(text, str): return ""
    text = text.replace("<S2SV_ModStart>", "").replace("<S2SV_ModEnd>", "")
    return re.sub(r'\s+', '', text)


def calc_metrics(preds, targets):
    total = len(preds)
    em_count = 0
    edit_sims = []

    # 【修复重点】分离两种格式
    # CodeBLEU 格式: [[t1], [t2], ...] (N个列表)
    refs_for_codebleu = [[t] for t in targets]

    # SacreBLEU 格式: [[t1, t2, ...]] (1个列表包含所有)
    refs_for_sacrebleu = [targets]

    hyps_for_bleu = preds

    logger.info("Computing Metrics...")
    for p, t in zip(preds, targets):
        norm_p = normalize_code_loose(p)
        norm_t = normalize_code_loose(t)
        if norm_p == norm_t: em_count += 1

        dist = Levenshtein.distance(norm_p, norm_t)
        max_len = max(len(norm_p), len(norm_t))
        sim = 1.0 - (dist / max_len) if max_len > 0 else (1.0 if dist == 0 else 0.0)
        edit_sims.append(sim)

    bleu_score = 0.0
    metric_name = "None"

    if HAS_CODEBLEU:
        try:
            # 使用 CodeBLEU 格式
            res = calc_codebleu(refs_for_codebleu, hyps_for_bleu, lang="cpp", weights=(0.25, 0.25, 0.25, 0.25))
            bleu_score = res['codebleu']
            metric_name = "CodeBLEU"
        except:
            pass

    if metric_name == "None" and HAS_SACREBLEU:
        try:
            bleu = BLEU()
            # 【修复重点】使用 SacreBLEU 格式
            bleu_score = bleu.corpus_score(hyps_for_bleu, refs_for_sacrebleu).score / 100.0
            metric_name = "SacreBLEU"
        except Exception as e:
            logger.warning(f"SacreBLEU failed: {e}")

    return {"EM": em_count / total, "EditSim": sum(edit_sims) / total, "BLEU_Score": bleu_score,
            "BLEU_Type": metric_name}


def main():
    model, tokenizer = load_model_and_tokenizer()
    df = pd.read_csv(TEST_DATA_PATH).dropna(subset=['target', 'new_source'])

    # 提前清洗 Target
    raw_targets = df['target'].tolist()
    clean_targets = [extract_code_content(t) for t in raw_targets]

    prompts = [build_prompt(row, tokenizer) for _, row in df.iterrows()]

    logger.info(f"🤖 Starting Inference on {len(prompts)} samples...")
    predictions = []

    temp_save_path = os.path.join(RESULT_DIR, "temp_predictions.jsonl")
    if os.path.exists(temp_save_path): os.remove(temp_save_path)

    for i in tqdm(range(0, len(prompts), BATCH_SIZE)):
        batch_prompts = prompts[i: i + BATCH_SIZE]
        inputs = tokenizer(batch_prompts, return_tensors="pt", padding=True, truncation=True, max_length=4096).to(
            DEVICE)

        with torch.no_grad():
            outputs = model.generate(
                **inputs,
                max_new_tokens=MAX_NEW_TOKENS,
                do_sample=False,
                pad_token_id=tokenizer.pad_token_id,
                eos_token_id=tokenizer.eos_token_id,
                use_cache=True
            )

        generated_tokens = outputs[:, inputs.input_ids.shape[1]:]
        batch_preds_raw = tokenizer.batch_decode(generated_tokens, skip_special_tokens=False)

        batch_preds_clean = []
        for text in batch_preds_raw:
            for eos in ["<|im_end|>", "<|endoftext|>"]:
                if eos in text: text = text.split(eos)[0]
            if tokenizer.pad_token: text = text.replace(tokenizer.pad_token, "")

            clean_code = extract_code_content(text.strip())
            batch_preds_clean.append(clean_code)

        predictions.extend(batch_preds_clean)

        with open(temp_save_path, "a", encoding="utf-8") as f:
            for p in batch_preds_clean:
                f.write(json.dumps({"prediction": p}, ensure_ascii=False) + "\n")

    # 使用 clean_targets 计算指标
    metrics = calc_metrics(predictions, clean_targets)
    print(
        f"\n📊 Results: EM={metrics['EM']:.2%}, EditSim={metrics['EditSim']:.2%}, {metrics['BLEU_Type']}={metrics['BLEU_Score']:.4f}\n")

    correct_samples = []
    incorrect_samples = []
    for i, (pred, clean_tgt) in enumerate(zip(predictions, clean_targets)):
        norm_p = normalize_code_loose(pred)
        norm_t = normalize_code_loose(clean_tgt)
        is_correct = (norm_p == norm_t)

        item = {
            "source": df.iloc[i]['new_source'],
            "target_raw": raw_targets[i],
            "target_extracted": clean_tgt,
            "prediction_extracted": pred,
            "loose_match": is_correct
        }
        if is_correct:
            correct_samples.append(item)
        else:
            incorrect_samples.append(item)

    with open(os.path.join(RESULT_DIR, "correct_samples.json"), "w") as f:
        json.dump(correct_samples, f, indent=2)
    with open(os.path.join(RESULT_DIR, "incorrect_samples.json"), "w") as f:
        json.dump(incorrect_samples, f, indent=2)

    if os.path.exists(temp_save_path): os.remove(temp_save_path)
    logger.info("✅ Done!")


if __name__ == "__main__":
    main()