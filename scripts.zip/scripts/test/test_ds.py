import os
import json
import torch
import logging
import pandas as pd
import numpy as np
from tqdm import tqdm
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
from peft import PeftModel
import Levenshtein
import re
from transformers.cache_utils import DynamicCache

# =========================================================
# 🩹 基础兼容性补丁
# =========================================================
if not hasattr(DynamicCache, "get_usable_length"):
    def get_usable_length(self, input_seq_length, layer_idx=None):
        return input_seq_length


    DynamicCache.get_usable_length = get_usable_length

# =========================================================
# 📦 导入评估库 (带防报错)
# =========================================================
HAS_CODEBLEU = False
HAS_SACREBLEU = False
try:
    from codebleu import calc_codebleu

    HAS_CODEBLEU = True
except ImportError:
    pass
try:
    from sacrebleu.metrics import BLEU

    HAS_SACREBLEU = True
except ImportError:
    pass

# =========================================================
# ⚙️ 配置区域 (Server A: zhangzl)
# =========================================================
BASE_MODEL_PATH = "/home/zhangzl/projects/LLM_fix/models/DeepSeek-Coder-V2-Lite-Instruct/"
ADAPTER_PATH = "/home/zhangzl/projects/LLM_fix/outputs/DeepSeek-V2-Lite-Final"
TEST_DATA_PATH = "/home/zhangzl/projects/CodeLlama/data/my_data/data_v3/test.csv"
RESULT_DIR = "/home/zhangzl/projects/LLM_fix/outputs/deepseek_result/"
os.makedirs(RESULT_DIR, exist_ok=True)

MAX_NEW_TOKENS = 1024

# 【核心策略】先用 1 跑通，确认不卡。
# 如果跑起来显示速度很快(例如 >2it/s)，可以按 Ctrl+C 停止，把这里改成 4 或 8 再跑
BATCH_SIZE = 1
DEVICE = "cuda"

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


def load_model_and_tokenizer():
    logger.info("🚀 Loading Tokenizer...")
    tokenizer = AutoTokenizer.from_pretrained(BASE_MODEL_PATH, trust_remote_code=True)
    SPECIAL_TOKENS = ["<MODIFY_HERE>", "</MODIFY_HERE>", "<S2SV_ModStart>", "<S2SV_ModEnd>"]
    tokenizer.add_tokens(SPECIAL_TOKENS)
    tokenizer.padding_side = "left"
    if tokenizer.pad_token is None: tokenizer.pad_token = tokenizer.eos_token

    logger.info("🚀 Loading Base Model (4-bit FORCE GPU)...")

    # 4-bit 量化配置
    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_compute_dtype=torch.bfloat16,
        bnb_4bit_use_double_quant=True,
        bnb_4bit_quant_type="nf4"
    )

    try:
        model = AutoModelForCausalLM.from_pretrained(
            BASE_MODEL_PATH,
            quantization_config=bnb_config,
            trust_remote_code=True,
            # 【关键修改】强制使用第一块 GPU，拒绝 CPU Offload
            device_map="cuda:0",
            attn_implementation="eager"
        )
    except Exception as e:
        logger.error(f"Error loading model: {e}")
        logger.error("🛑 错误提示: 如果报显存不足，请检查是否有其他进程占用显存。")
        raise e

    model.config.use_cache = False
    model.resize_token_embeddings(len(tokenizer))

    logger.info(f"🚀 Loading LoRA Adapter...")
    model = PeftModel.from_pretrained(model, ADAPTER_PATH)
    model.eval()
    return model, tokenizer


def build_prompt(row, tokenizer):
    sys_msg = (
        "You are an expert vulnerability repair system. "
        "The input code contains one or more segments marked with <MODIFY_HERE>. "
        "Your task is to output the correct fixed code for EACH <MODIFY_HERE> segment, in order. "
        "Wrap each fix in <S2SV_ModStart> and <S2SV_ModEnd> tags. Output ONLY the code. Do not explain."
    )
    user_msg = f"Fix the marked bugs in the following code:\n\n{row['new_source']}\n"
    messages = [{"role": "system", "content": sys_msg}, {"role": "user", "content": user_msg}]
    return tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)


def extract_code_content(text):
    pattern = r"<S2SV_ModStart>(.*?)<S2SV_ModEnd>"
    matches = re.findall(pattern, text, re.DOTALL)
    if matches: return " ".join(matches).strip()
    return text.strip()


def normalize_code_loose(text):
    if not isinstance(text, str): return ""
    text = text.replace("<S2SV_ModStart>", "").replace("<S2SV_ModEnd>", "")
    return re.sub(r'\s+', '', text)


def calc_metrics(preds, targets):
    total = len(preds)
    em_count = 0
    edit_sims = []

    refs_for_codebleu = [[t] for t in targets]
    refs_for_sacrebleu = [targets]
    hyps_for_bleu = preds

    logger.info("Computing Metrics...")
    for p, t in zip(preds, targets):
        norm_p = normalize_code_loose(p)
        norm_t = normalize_code_loose(t)
        if norm_p == norm_t: em_count += 1
        dist = Levenshtein.distance(norm_p, norm_t)
        max_len = max(len(norm_p), len(norm_t))
        sim = 1.0 - (dist / max_len) if max_len > 0 else (1.0 if dist == 0 else 0.0)
        edit_sims.append(sim)

    bleu_score = 0.0
    metric_name = "None"

    if HAS_CODEBLEU:
        try:
            res = calc_codebleu(refs_for_codebleu, hyps_for_bleu, lang="cpp", weights=(0.25, 0.25, 0.25, 0.25))
            bleu_score = res['codebleu']
            metric_name = "CodeBLEU"
        except:
            pass

    if metric_name == "None" and HAS_SACREBLEU:
        try:
            bleu = BLEU()
            bleu_score = bleu.corpus_score(hyps_for_bleu, refs_for_sacrebleu).score / 100.0
            metric_name = "SacreBLEU"
        except:
            pass

    return {"EM": em_count / total, "EditSim": sum(edit_sims) / total, "BLEU_Score": bleu_score,
            "BLEU_Type": metric_name}


def main():
    model, tokenizer = load_model_and_tokenizer()
    df = pd.read_csv(TEST_DATA_PATH).dropna(subset=['target', 'new_source'])
    raw_targets = df['target'].tolist()
    clean_targets = [extract_code_content(t) for t in raw_targets]
    prompts = [build_prompt(row, tokenizer) for _, row in df.iterrows()]
    sources = df['new_source'].tolist()

    logger.info(f"🤖 Starting Inference on {len(prompts)} samples...")
    predictions = []

    temp_save_path = os.path.join(RESULT_DIR, "temp_deepseek_predictions.jsonl")
    if os.path.exists(temp_save_path): os.remove(temp_save_path)

    for i in tqdm(range(0, len(prompts), BATCH_SIZE)):
        batch_prompts = prompts[i: i + BATCH_SIZE]
        inputs = tokenizer(batch_prompts, return_tensors="pt", padding=True, truncation=True, max_length=4096).to(
            DEVICE)

        with torch.no_grad():
            outputs = model.generate(
                **inputs,
                max_new_tokens=MAX_NEW_TOKENS,
                do_sample=False,
                pad_token_id=tokenizer.pad_token_id,
                eos_token_id=tokenizer.eos_token_id,
                use_cache=False
            )

        generated_tokens = outputs[:, inputs.input_ids.shape[1]:]
        batch_preds_raw = tokenizer.batch_decode(generated_tokens, skip_special_tokens=False)

        batch_preds_clean = []
        for text in batch_preds_raw:
            for eos in [tokenizer.eos_token, "<|endoftext|>", "<｜end of sentence｜>"]:
                if eos and eos in text: text = text.split(eos)[0]
            if tokenizer.pad_token: text = text.replace(tokenizer.pad_token, "")
            batch_preds_clean.append(extract_code_content(text.strip()))

        predictions.extend(batch_preds_clean)

        with open(temp_save_path, "a", encoding="utf-8") as f:
            for p in batch_preds_clean:
                f.write(json.dumps({"prediction": p}, ensure_ascii=False) + "\n")

    metrics = calc_metrics(predictions, clean_targets)
    print(
        f"\n📊 Results: EM={metrics['EM']:.2%}, EditSim={metrics['EditSim']:.2%}, {metrics['BLEU_Type']}={metrics['BLEU_Score']:.4f}\n")

    correct_samples = []
    incorrect_samples = []
    for i, (pred, clean_tgt) in enumerate(zip(predictions, clean_targets)):
        norm_p = normalize_code_loose(pred)
        norm_t = normalize_code_loose(clean_tgt)
        is_correct = (norm_p == norm_t)
        item = {
            "source": sources[i],
            "target_raw": raw_targets[i],
            "target_extracted": clean_tgt,
            "prediction_extracted": pred,
            "loose_match": is_correct
        }
        if is_correct:
            correct_samples.append(item)
        else:
            incorrect_samples.append(item)

    with open(os.path.join(RESULT_DIR, "correct.json"), "w") as f:
        json.dump(correct_samples, f, indent=2)
    with open(os.path.join(RESULT_DIR, "incorrect.json"), "w") as f:
        json.dump(incorrect_samples, f, indent=2)
    if os.path.exists(temp_save_path): os.remove(temp_save_path)
    logger.info("✅ Done!")


if __name__ == "__main__":
    main()