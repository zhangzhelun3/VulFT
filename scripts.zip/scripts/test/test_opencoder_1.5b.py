import os
import json
import torch
import logging
import pandas as pd
import numpy as np
from tqdm import tqdm
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
from peft import PeftModel
import re
import Levenshtein

# =========================================================
# 📦 导入评估指标库 (自动降级)
# =========================================================
HAS_CODEBLEU = False
HAS_SACREBLEU = False

try:
    from codebleu import calc_codebleu

    HAS_CODEBLEU = True
except ImportError:
    print("⚠️ 'codebleu' not found. Skipping CodeBLEU.")

try:
    from sacrebleu.metrics import BLEU

    HAS_SACREBLEU = True
except ImportError:
    print("⚠️ 'sacrebleu' not found. Skipping SacreBLEU.")

# =========================================================
# ⚙️ 配置区域 (Server B - OpenCoder 1.5B)
# =========================================================
BASE_MODEL_PATH = "/home/sea1001/projects/LLM_fix/models/OpenCoder-1.5B-Base"
ADAPTER_PATH = "/home/sea1001/projects/LLM_fix/outputs/OpenCoder-1.5B-Fix"
TEST_DATA_PATH = "/home/sea1001/projects/CodeLlama/data/my_data/data_v3/test.csv"
RESULT_DIR = "/home/sea1001/projects/LLM_fix/outputs/opencoder_1.5b_result/"
os.makedirs(RESULT_DIR, exist_ok=True)

# 推理参数
MAX_NEW_TOKENS = 512
# 🚀 1.5B 模型在 A100 上非常小，Batch Size 可以开大一点，速度起飞
BATCH_SIZE = 16
DEVICE = "cuda"

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


def load_model_and_tokenizer():
    logger.info("🚀 Loading Tokenizer...")
    tokenizer = AutoTokenizer.from_pretrained(BASE_MODEL_PATH, trust_remote_code=True)

    # 【重点1】推理时 Padding 必须在左边！
    tokenizer.padding_side = "left"
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    # 【重点2】必须添加和训练时一样的特殊 Token
    # 注意：OpenCoder 1.5B 训练脚本中我们也添加了这些 Token 并 resize 了 embedding
    SPECIAL_TOKENS = ["<MODIFY_HERE>", "</MODIFY_HERE>", "<S2SV_ModStart>", "<S2SV_ModEnd>"]
    tokenizer.add_tokens(SPECIAL_TOKENS)

    logger.info("🚀 Loading Model (4-bit)...")
    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_compute_dtype=torch.bfloat16,  # 训练时用了 bf16，这里保持一致
        bnb_4bit_quant_type="nf4",
        bnb_4bit_use_double_quant=True
    )

    model = AutoModelForCausalLM.from_pretrained(
        BASE_MODEL_PATH,
        quantization_config=bnb_config,
        trust_remote_code=True,
        device_map="auto",
        attn_implementation="eager"
    )

    # 调整 Embedding 大小 (必须做，否则加载 Adapter 会报错)
    model.resize_token_embeddings(len(tokenizer))

    logger.info(f"🚀 Loading LoRA Adapter from {ADAPTER_PATH}...")
    model = PeftModel.from_pretrained(model, ADAPTER_PATH)
    model.eval()

    return model, tokenizer


def build_prompt(row):
    # 【重点3】Prompt 格式必须严格对齐训练脚本 (Alpaca Style)
    # 这与 train_opencoder_1.5b.py 中的 process_data_opencoder 保持完全一致
    prompt = (
        "### Instruction:\n"
        "You are a helpful coding assistant specialized in fixing bugs. "
        "The input code contains segments marked with <MODIFY_HERE>. "
        "Your task is to output the correct fixed code for EACH <MODIFY_HERE> segment, in order. "
        "Wrap each fix in <S2SV_ModStart> and <S2SV_ModEnd> tags.\n\n"
        "### Input Code:\n"
        f"{row['new_source']}\n\n"
        "### Fixed Code:\n"
    )
    return prompt


def extract_code_content(text):
    # 1. 优先提取 <S2SV_ModStart>...<S2SV_ModEnd>
    pattern = r"<S2SV_ModStart>(.*?)<S2SV_ModEnd>"
    matches = re.findall(pattern, text, re.DOTALL)

    if matches:
        return " ".join(matches).strip()

    # 2. 兜底策略：如果模型没输出 XML 标签，尝试提取 "### Fixed Code:" 之后的内容
    if "### Fixed Code:" in text:
        return text.split("### Fixed Code:")[-1].strip()

    return text.strip()


def normalize_code(text):
    if not isinstance(text, str): return ""
    text = text.replace("<S2SV_ModStart>", "").replace("<S2SV_ModEnd>", "")
    return re.sub(r'\s+', '', text)


def calc_metrics(preds, targets):
    total = len(preds)
    em_count = 0
    edit_sims = []

    refs_list = [[t] for t in targets]
    refs_sacre = [targets]

    logger.info("Computing Metrics...")
    for p, t in zip(preds, targets):
        norm_p = normalize_code(p)
        norm_t = normalize_code(t)

        if norm_p == norm_t:
            em_count += 1

        dist = Levenshtein.distance(norm_p, norm_t)
        max_len = max(len(norm_p), len(norm_t))
        sim = 1.0 - (dist / max_len) if max_len > 0 else (1.0 if dist == 0 else 0.0)
        edit_sims.append(sim)

    metrics = {
        "EM": em_count / total,
        "EditSim": sum(edit_sims) / total
    }

    if HAS_CODEBLEU:
        try:
            res = calc_codebleu(refs_list, preds, lang="cpp", weights=(0.25, 0.25, 0.25, 0.25))
            metrics["CodeBLEU"] = res['codebleu']
        except Exception as e:
            logger.warning(f"CodeBLEU calc failed: {e}")

    if HAS_SACREBLEU and "CodeBLEU" not in metrics:
        try:
            bleu = BLEU()
            metrics["SacreBLEU"] = bleu.corpus_score(preds, refs_sacre).score / 100.0
        except Exception as e:
            logger.warning(f"SacreBLEU calc failed: {e}")

    return metrics


def main():
    model, tokenizer = load_model_and_tokenizer()

    logger.info("📖 Loading Data...")
    df = pd.read_csv(TEST_DATA_PATH).dropna(subset=['target', 'new_source'])

    sources = df['new_source'].tolist()
    raw_targets = df['target'].tolist()
    clean_targets = [extract_code_content(t) for t in raw_targets]

    prompts = [build_prompt(row) for _, row in df.iterrows()]

    logger.info(f"⚡ Starting Inference on {len(prompts)} samples...")
    predictions = []

    # 批量推理循环
    for i in tqdm(range(0, len(prompts), BATCH_SIZE)):
        batch_prompts = prompts[i: i + BATCH_SIZE]

        inputs = tokenizer(batch_prompts, return_tensors="pt", padding=True, truncation=True, max_length=2048).to(
            DEVICE)
        input_len = inputs.input_ids.shape[1]

        with torch.no_grad():
            outputs = model.generate(
                **inputs,
                max_new_tokens=MAX_NEW_TOKENS,
                do_sample=False,  # 贪婪解码，保证结果确定性
                pad_token_id=tokenizer.pad_token_id,
                eos_token_id=tokenizer.eos_token_id,
                use_cache=True
            )

        # 只解码新生成的部分
        generated_tokens = outputs[:, input_len:]
        batch_decoded = tokenizer.batch_decode(generated_tokens, skip_special_tokens=False)

        for text in batch_decoded:
            # 清洗 EOS 和 Padding
            for eos in [tokenizer.eos_token, "<|endoftext|>"]:
                if eos in text:
                    text = text.split(eos)[0]

            # 提取纯代码
            clean_pred = extract_code_content(text)
            predictions.append(clean_pred)

    # 评估指标
    metrics = calc_metrics(predictions, clean_targets)
    print("\n" + "=" * 40)
    print(f"📊 Final Results (OpenCoder-1.5B):")
    print(f"Exact Match (EM): {metrics['EM']:.2%}")
    print(f"Edit Similarity:  {metrics['EditSim']:.2%}")
    if 'CodeBLEU' in metrics:
        print(f"CodeBLEU:         {metrics['CodeBLEU']:.4f}")
    elif 'SacreBLEU' in metrics:
        print(f"SacreBLEU:        {metrics['SacreBLEU']:.4f}")
    print("=" * 40 + "\n")

    # 保存详细结果
    results = []
    for i in range(len(predictions)):
        results.append({
            "source": sources[i],
            "target_raw": raw_targets[i],
            "target_clean": clean_targets[i],
            "prediction": predictions[i],
            "is_correct": normalize_code(predictions[i]) == normalize_code(clean_targets[i])
        })

    output_file = os.path.join(RESULT_DIR, "opencoder_1.5b_results.jsonl")
    pd.DataFrame(results).to_json(output_file, orient='records', lines=True)
    logger.info(f"✅ Results saved to {output_file}")


if __name__ == "__main__":
    main()