import os
import json
import torch
import logging
import pandas as pd
import numpy as np
from tqdm import tqdm
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
from peft import PeftModel
import re
import Levenshtein

# =========================================================
# 📦 导入评估指标库 (自动降级)
# =========================================================
HAS_CODEBLEU = False
HAS_SACREBLEU = False

try:
    from codebleu import calc_codebleu

    HAS_CODEBLEU = True
except ImportError:
    print("⚠️ 'codebleu' not found. Skipping CodeBLEU.")

try:
    from sacrebleu.metrics import BLEU

    HAS_SACREBLEU = True
except ImportError:
    print("⚠️ 'sacrebleu' not found. Skipping SacreBLEU.")

# =========================================================
# ⚙️ 配置区域 (Server A: zhangzl)
# =========================================================
BASE_MODEL_PATH = "/home/zhangzl/projects/LLM_fix/models/CodeLlama-7b-Instruct-hf"
ADAPTER_PATH = "/home/zhangzl/projects/LLM_fix/outputs/CodeLlama-7b-Fix-Stable"
TEST_DATA_PATH = "/home/zhangzl/projects/CodeLlama/data/my_data/data_v3/test.csv"
RESULT_DIR = "/home/zhangzl/projects/LLM_fix/outputs/codellama_result/"
os.makedirs(RESULT_DIR, exist_ok=True)

# 推理参数
MAX_NEW_TOKENS = 512
BATCH_SIZE = 16  # CodeLlama 7B 4bit 显存很小，16 跑起来很快
DEVICE = "cuda"

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


def load_model_and_tokenizer():
    logger.info("🚀 Loading Tokenizer...")
    tokenizer = AutoTokenizer.from_pretrained(BASE_MODEL_PATH, trust_remote_code=True)

    # 推理 Padding 在左边
    tokenizer.padding_side = "left"
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    # 🛑【核心修复】绝对不要 add_tokens，也不要 resize！
    # 因为我们在训练 Stable 版本时就没有加这些！
    # SPECIAL_TOKENS = [...] (已注释)
    # tokenizer.add_tokens(SPECIAL_TOKENS) (已注释)

    logger.info("🚀 Loading Model (4-bit)...")
    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_compute_dtype=torch.float16,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_use_double_quant=True
    )

    model = AutoModelForCausalLM.from_pretrained(
        BASE_MODEL_PATH,
        quantization_config=bnb_config,
        trust_remote_code=True,
        device_map="auto",
        attn_implementation="eager"
    )

    # 🛑【核心修复】不要 resize embedding
    # model.resize_token_embeddings(len(tokenizer)) (已注释)

    logger.info(f"🚀 Loading LoRA Adapter from {ADAPTER_PATH}...")
    model = PeftModel.from_pretrained(model, ADAPTER_PATH)
    model.eval()

    return model, tokenizer


def build_prompt(row):
    # 🛑【核心修复】Prompt 必须严格对齐训练时的 process_data_codellama
    # 训练时使用了 <<SYS>> 标签
    sys_msg = (
        "You are a helpful coding assistant specialized in fixing bugs. "
        "The input code contains segments marked with <MODIFY_HERE>. "
        "Your task is to output the correct fixed code for EACH <MODIFY_HERE> segment, in order. "
        "Wrap each fix in <S2SV_ModStart> and <S2SV_ModEnd> tags."
    )
    user_msg = f"The following code contains bugs:\n{row['new_source']}\n\nRepair the bugs."

    # 构造完整 Prompt: [INST] <<SYS>>\n{sys}\n<</SYS>>\n\n{user} [/INST]
    prompt = f"[INST] <<SYS>>\n{sys_msg}\n<</SYS>>\n\n{user_msg} [/INST]"
    return prompt


def extract_code_content(text):
    pattern = r"<S2SV_ModStart>(.*?)<S2SV_ModEnd>"
    matches = re.findall(pattern, text, re.DOTALL)
    if matches:
        return " ".join(matches).strip()

    # 兜底清洗
    if "[/INST]" in text:
        text = text.split("[/INST]")[-1]
    return text.strip()


def normalize_code(text):
    if not isinstance(text, str): return ""
    text = text.replace("<S2SV_ModStart>", "").replace("<S2SV_ModEnd>", "")
    return re.sub(r'\s+', '', text)


def calc_metrics(preds, targets):
    total = len(preds)
    em_count = 0
    edit_sims = []

    # 准备 CodeBLEU 需要的数据格式
    refs_list = [[t] for t in targets]
    refs_sacre = [targets]

    logger.info("Computing Metrics...")
    for p, t in zip(preds, targets):
        norm_p = normalize_code(p)
        norm_t = normalize_code(t)
        if norm_p == norm_t:
            em_count += 1
        dist = Levenshtein.distance(norm_p, norm_t)
        max_len = max(len(norm_p), len(norm_t))
        sim = 1.0 - (dist / max_len) if max_len > 0 else (1.0 if dist == 0 else 0.0)
        edit_sims.append(sim)

    metrics = {
        "EM": em_count / total,
        "EditSim": sum(edit_sims) / total
    }

    # 恢复 CodeBLEU 计算
    if HAS_CODEBLEU:
        try:
            # 权重: ngram, weighted_ngram, syntax, dataflow
            res = calc_codebleu(refs_list, preds, lang="cpp", weights=(0.25, 0.25, 0.25, 0.25))
            metrics["CodeBLEU"] = res['codebleu']
        except Exception as e:
            logger.warning(f"CodeBLEU calc failed: {e}")

    # 恢复 SacreBLEU 计算
    if HAS_SACREBLEU and "CodeBLEU" not in metrics:
        try:
            bleu = BLEU()
            metrics["SacreBLEU"] = bleu.corpus_score(preds, refs_sacre).score / 100.0
        except Exception as e:
            logger.warning(f"SacreBLEU calc failed: {e}")

    return metrics


def main():
    model, tokenizer = load_model_and_tokenizer()

    logger.info("📖 Loading Data...")
    df = pd.read_csv(TEST_DATA_PATH).dropna(subset=['target', 'new_source'])

    prompts = [build_prompt(row) for _, row in df.iterrows()]
    raw_targets = df['target'].tolist()
    clean_targets = [extract_code_content(t) for t in raw_targets]

    logger.info(f"⚡ Starting Inference on {len(prompts)} samples...")
    predictions = []

    # BATCH_SIZE 调大到 16
    for i in tqdm(range(0, len(prompts), BATCH_SIZE)):
        batch_prompts = prompts[i: i + BATCH_SIZE]

        inputs = tokenizer(batch_prompts, return_tensors="pt", padding=True, truncation=True, max_length=2048).to(
            DEVICE)
        input_len = inputs.input_ids.shape[1]

        with torch.no_grad():
            outputs = model.generate(
                **inputs,
                max_new_tokens=MAX_NEW_TOKENS,
                do_sample=False,
                pad_token_id=tokenizer.pad_token_id,
                eos_token_id=tokenizer.eos_token_id,
                use_cache=True
            )

        generated_tokens = outputs[:, input_len:]
        batch_decoded = tokenizer.batch_decode(generated_tokens, skip_special_tokens=False)

        for text in batch_decoded:
            for eos in [tokenizer.eos_token, "</s>"]:
                if eos in text:
                    text = text.split(eos)[0]
            clean_pred = extract_code_content(text)
            predictions.append(clean_pred)

    metrics = calc_metrics(predictions, clean_targets)
    print("\n" + "=" * 40)
    print(f"📊 Final Results (CodeLlama-7B):")
    print(f"Exact Match (EM): {metrics['EM']:.2%}")
    print(f"Edit Similarity:  {metrics['EditSim']:.2%}")
    if 'CodeBLEU' in metrics:
        print(f"CodeBLEU:         {metrics['CodeBLEU']:.4f}")
    elif 'SacreBLEU' in metrics:
        print(f"SacreBLEU:        {metrics['SacreBLEU']:.4f}")
    print("=" * 40 + "\n")

    # 保存
    results = []
    for i in range(len(predictions)):
        results.append({
            "source": prompts[i],  # 存 Prompt 方便复查
            "target_clean": clean_targets[i],
            "prediction": predictions[i],
            "is_correct": normalize_code(predictions[i]) == normalize_code(clean_targets[i])
        })

    output_file = os.path.join(RESULT_DIR, "codellama_results.jsonl")
    pd.DataFrame(results).to_json(output_file, orient='records', lines=True)
    logger.info(f"✅ Saved to {output_file}")


if __name__ == "__main__":
    main()