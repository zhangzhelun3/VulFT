import os
import torch
import logging
import pandas as pd
import numpy as np
from datasets import Dataset
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training, TaskType
from transformers import (
    AutoTokenizer,
    AutoModelForCausalLM,
    TrainingArguments,
    Trainer,
    DataCollatorForSeq2Seq,
    BitsAndBytesConfig,
    EarlyStoppingCallback
)

# ========== 1. 终极配置 (Server B) ==========
MODEL_PATH = "/home/sea1001/projects/LLM_fix/models/OpenCoder-8B-Base"
OUTPUT_DIR = "/home/sea1001/projects/LLM_fix/outputs/OpenCoder-8B-Fix"
TRAIN_DATA_PATH = "/home/sea1001/projects/CodeLlama/data/my_data/data_v3/train.csv"
VAL_DATA_PATH = "/home/sea1001/projects/CodeLlama/data/my_data/data_v3/val.csv"

# 训练参数
NUM_EPOCHS = 3
MAX_LENGTH = 2048
BATCH_SIZE = 8
GRAD_ACCUM_STEPS = 4
LEARNING_RATE = 1e-4

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# 🔴 关键修改 1: 定义一个全局变量 tokenizer，避免在 map 中传递对象
global_tokenizer = None


# ========== 2. 数据处理 (引用全局变量版) ==========
def process_data_opencoder(row):
    # 直接使用全局变量，避免 pickle 报错
    global global_tokenizer
    tokenizer = global_tokenizer

    # 1. 构建 Input 部分 (Alpaca 风格 Prompt)
    prompt_text = (
        "### Instruction:\n"
        "You are a helpful coding assistant specialized in fixing bugs. "
        "The input code contains segments marked with <MODIFY_HERE>. "
        "Your task is to output the correct fixed code for EACH <MODIFY_HERE> segment, in order. "
        "Wrap each fix in <S2SV_ModStart> and <S2SV_ModEnd> tags.\n\n"
        "### Input Code:\n"
        f"{row['new_source']}\n\n"
        "### Fixed Code:\n"
    )

    # 2. Tokenize Prompt
    input_ids = tokenizer(prompt_text, add_special_tokens=False)["input_ids"]

    # 3. Tokenize Target
    target_str = row['completion']
    target_ids = tokenizer(target_str, add_special_tokens=False)["input_ids"]

    # 4. 拼接 + 加上 EOS
    eos_id = tokenizer.eos_token_id
    full_ids = input_ids + target_ids + [eos_id]

    # 5. 截断
    if len(full_ids) > MAX_LENGTH:
        full_ids = full_ids[:MAX_LENGTH]

    input_ids_tensor = torch.tensor(full_ids, dtype=torch.long)
    labels = input_ids_tensor.clone()

    # 6. Mask Prompt (只训练回答部分)
    prompt_len = len(input_ids)
    if prompt_len > len(labels):
        prompt_len = len(labels)
    labels[:prompt_len] = -100

    return {
        "input_ids": input_ids_tensor,
        "labels": labels,
        "attention_mask": torch.ones(len(full_ids), dtype=torch.long)
    }


# ========== 主程序 ==========
def main():
    global global_tokenizer  # 声明我们要修改全局变量

    logger.info("🚀 Loading Tokenizer...")
    # 初始化全局 tokenizer
    global_tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH, trust_remote_code=True)

    # 【检查点1】Padding Side 必须为 Right
    global_tokenizer.padding_side = "right"
    if global_tokenizer.pad_token is None:
        print("🔧 Setting pad_token to eos_token...")
        global_tokenizer.pad_token = global_tokenizer.eos_token

    # 【检查点2】添加特殊 Token
    SPECIAL_TOKENS = ["<MODIFY_HERE>", "</MODIFY_HERE>", "<S2SV_ModStart>", "<S2SV_ModEnd>"]
    num_added = global_tokenizer.add_tokens(SPECIAL_TOKENS)
    logger.info(f"已添加 {num_added} 个特殊 Token")

    # 2. 数据加载
    def load_ds(path):
        df = pd.read_csv(path)
        df = df[df['target'].str.contains("<S2SV_ModStart>", na=False)]
        df['completion'] = df['target']
        return Dataset.from_pandas(df.dropna(subset=['completion']))

    train_ds = load_ds(TRAIN_DATA_PATH)
    val_ds = load_ds(VAL_DATA_PATH)

    # 🔴 关键修改 2: map 时不再传递 tokenizer 参数，且禁用缓存
    # process_data_opencoder 现在是无参调用（利用全局变量）
    logger.info("⏳ Processing data (No serialization)...")

    train_ds = train_ds.map(
        process_data_opencoder,
        remove_columns=train_ds.column_names,
        num_proc=1,
        load_from_cache_file=False  # 禁用缓存，防止尝试 hash tokenizer
    )

    val_ds = val_ds.map(
        process_data_opencoder,
        remove_columns=val_ds.column_names,
        num_proc=1,
        load_from_cache_file=False
    )

    # 3. 模型加载 (4-bit QLoRA)
    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_compute_dtype=torch.bfloat16,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_use_double_quant=True
    )

    logger.info("🚀 Loading Model (4-bit)...")
    model = AutoModelForCausalLM.from_pretrained(
        MODEL_PATH,
        quantization_config=bnb_config,
        trust_remote_code=True,
        device_map="auto"
    )

    # 调整 Embedding 大小以适应新 Token
    model.resize_token_embeddings(len(global_tokenizer))

    # 4. LoRA 配置
    model = prepare_model_for_kbit_training(model)

    peft_config = LoraConfig(
        r=8,
        lora_alpha=16,
        target_modules=["q_proj", "v_proj"],
        modules_to_save=["embed_tokens", "lm_head"],
        lora_dropout=0.05,
        bias="none",
        task_type="CAUSAL_LM"
    )
    model = get_peft_model(model, peft_config)
    model.print_trainable_parameters()

    # 5. Trainer 配置
    args = TrainingArguments(
        output_dir=OUTPUT_DIR,
        overwrite_output_dir=True,
        per_device_train_batch_size=BATCH_SIZE,
        gradient_accumulation_steps=GRAD_ACCUM_STEPS,
        learning_rate=LEARNING_RATE,
        num_train_epochs=NUM_EPOCHS,

        warmup_steps=100,
        lr_scheduler_type="cosine",

        eval_strategy="steps",
        eval_steps=500,
        save_strategy="steps",
        save_steps=500,
        save_total_limit=2,
        load_best_model_at_end=True,
        metric_for_best_model="loss",
        greater_is_better=False,

        bf16=True,
        logging_steps=10,
        optim="paged_adamw_32bit",
        report_to="none",
        gradient_checkpointing=True,
        dataloader_num_workers=4,
        group_by_length=True,
    )

    early_stopping = EarlyStoppingCallback(early_stopping_patience=3)
    # 注意这里也要用 global_tokenizer
    data_collator = DataCollatorForSeq2Seq(global_tokenizer, padding=True, pad_to_multiple_of=8)

    # 6. 训练
    trainer = Trainer(
        model=model,
        args=args,
        train_dataset=train_ds,
        eval_dataset=val_ds,
        data_collator=data_collator,
        callbacks=[early_stopping]
    )

    logger.info("🔥 Starting Training OpenCoder...")
    trainer.train()

    logger.info("💾 Saving model...")
    trainer.save_model(OUTPUT_DIR)
    global_tokenizer.save_pretrained(OUTPUT_DIR)
    print(f"✅ 完成！模型已保存至: {OUTPUT_DIR}")


if __name__ == "__main__":
    main()