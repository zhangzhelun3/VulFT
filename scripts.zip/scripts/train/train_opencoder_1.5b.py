import os
import torch
import logging
import pandas as pd
import numpy as np
from datasets import Dataset
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training, TaskType
from transformers import (
    AutoTokenizer,
    AutoModelForCausalLM,
    TrainingArguments,
    Trainer,
    DataCollatorForSeq2Seq,
    BitsAndBytesConfig,
    EarlyStoppingCallback
)

# ==========================================
# ⚙️ 1. 配置区域 (Server B: sea1001)
# ==========================================
# ⚠️ 修改模型路径为 1.5B
MODEL_PATH = "/home/sea1001/projects/LLM_fix/models/OpenCoder-1.5B-Base"
OUTPUT_DIR = "/home/sea1001/projects/LLM_fix/outputs/OpenCoder-1.5B-Fix"

TRAIN_DATA_PATH = "/home/sea1001/projects/CodeLlama/data/my_data/data_v3/train.csv"
VAL_DATA_PATH = "/home/sea1001/projects/CodeLlama/data/my_data/data_v3/val.csv"

# 🚀 激进参数调整 (针对 1.5B + A100)
NUM_EPOCHS = 3
MAX_LENGTH = 2048
BATCH_SIZE = 16  # ⬆️ 1.5B 模型很小，A100 可以轻松跑 32 甚至 64
GRAD_ACCUM_STEPS = 2  # 等效 Batch = 64
LEARNING_RATE = 2e-4  # ⬆️ 小模型可以适当提高学习率

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# 全局变量，防止多进程 pickle 报错
global_tokenizer = None


# ==========================================
# 🛠️ 2. 数据处理 (Alpaca 格式)
# ==========================================
def process_data_opencoder(row):
    global global_tokenizer
    tokenizer = global_tokenizer

    # OpenCoder-Base 没有自带对话模板，使用 Alpaca 格式进行指令微调
    prompt_text = (
        "### Instruction:\n"
        "You are a helpful coding assistant specialized in fixing bugs. "
        "The input code contains segments marked with <MODIFY_HERE>. "
        "Your task is to output the correct fixed code for EACH <MODIFY_HERE> segment, in order. "
        "Wrap each fix in <S2SV_ModStart> and <S2SV_ModEnd> tags.\n\n"
        "### Input Code:\n"
        f"{row['new_source']}\n\n"
        "### Fixed Code:\n"
    )

    # Tokenize Input
    input_ids = tokenizer(prompt_text, add_special_tokens=False)["input_ids"]

    # Tokenize Output
    target_str = row['completion']
    target_ids = tokenizer(target_str, add_special_tokens=False)["input_ids"]

    # 拼接 + EOS
    eos_id = tokenizer.eos_token_id
    full_ids = input_ids + target_ids + [eos_id]

    # 截断
    if len(full_ids) > MAX_LENGTH:
        full_ids = full_ids[:MAX_LENGTH]

    input_ids_tensor = torch.tensor(full_ids, dtype=torch.long)
    labels = input_ids_tensor.clone()

    # Mask Prompt
    prompt_len = len(input_ids)
    if prompt_len > len(labels):
        prompt_len = len(labels)
    labels[:prompt_len] = -100

    return {
        "input_ids": input_ids_tensor,
        "labels": labels,
        "attention_mask": torch.ones(len(full_ids), dtype=torch.long)
    }


# ==========================================
# 🚀 3. 主程序
# ==========================================
def main():
    global global_tokenizer

    logger.info("🚀 Loading Tokenizer...")
    global_tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH, trust_remote_code=True)

    global_tokenizer.padding_side = "right"
    if global_tokenizer.pad_token is None:
        logger.info("🔧 Setting pad_token to eos_token...")
        global_tokenizer.pad_token = global_tokenizer.eos_token

    # 添加特殊 Token (保持原逻辑)
    SPECIAL_TOKENS = ["<MODIFY_HERE>", "</MODIFY_HERE>", "<S2SV_ModStart>", "<S2SV_ModEnd>"]
    num_added = global_tokenizer.add_tokens(SPECIAL_TOKENS)
    logger.info(f"已添加 {num_added} 个特殊 Token")

    # 加载数据
    def load_ds(path):
        df = pd.read_csv(path).dropna(subset=['target', 'new_source'])
        df = df[df['target'].str.contains("<S2SV_ModStart>", na=False)]
        df['completion'] = df['target']
        return Dataset.from_pandas(df)

    train_ds = load_ds(TRAIN_DATA_PATH)
    val_ds = load_ds(VAL_DATA_PATH)

    logger.info("⏳ Processing data (No serialization)...")
    train_ds = train_ds.map(process_data_opencoder, remove_columns=train_ds.column_names, num_proc=1,
                            load_from_cache_file=False)
    val_ds = val_ds.map(process_data_opencoder, remove_columns=val_ds.column_names, num_proc=1,
                        load_from_cache_file=False)

    # 模型加载 (4-bit QLoRA)
    # 虽然 A100 跑 1.5B 其实不需要 QLoRA，但为了保持代码结构一致性，我们继续沿用
    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_compute_dtype=torch.bfloat16,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_use_double_quant=True
    )

    logger.info("🚀 Loading Model (4-bit)...")
    model = AutoModelForCausalLM.from_pretrained(
        MODEL_PATH,
        quantization_config=bnb_config,
        trust_remote_code=True,
        device_map="auto",
        attn_implementation="eager"  # 防止 FlashAttn 版本不匹配，小模型 eager 也不慢
    )

    # 禁用 Cache
    model.config.use_cache = False

    # Resize Embedding
    model.resize_token_embeddings(len(global_tokenizer))

    # LoRA 配置
    model = prepare_model_for_kbit_training(model)
    peft_config = LoraConfig(
        r=16,  # ⬆️ 提升 Rank 到 16，增强表达能力
        lora_alpha=32,
        target_modules=["q_proj", "v_proj"],
        modules_to_save=["embed_tokens", "lm_head"],
        lora_dropout=0.05,
        bias="none",
        task_type="CAUSAL_LM"
    )
    model = get_peft_model(model, peft_config)
    model.print_trainable_parameters()

    # Trainer 配置
    args = TrainingArguments(
        output_dir=OUTPUT_DIR,
        overwrite_output_dir=True,
        per_device_train_batch_size=BATCH_SIZE,
        gradient_accumulation_steps=GRAD_ACCUM_STEPS,
        learning_rate=LEARNING_RATE,
        num_train_epochs=NUM_EPOCHS,

        warmup_steps=100,
        lr_scheduler_type="cosine",

        # 验证设置
        eval_strategy="steps",
        eval_steps=400,  # 1.5B 跑得快，可以测勤一点
        save_strategy="steps",
        save_steps=400,
        save_total_limit=2,
        load_best_model_at_end=True,
        metric_for_best_model="loss",
        greater_is_better=False,

        # 稳定性设置 (吸取之前的教训)
        bf16=True,
        bf16_full_eval=True,  # ⚠️ 防止 Eval NaN
        max_grad_norm=0.5,  # ⚠️ 防止梯度爆炸

        logging_steps=10,
        optim="paged_adamw_32bit",
        report_to="none",
        gradient_checkpointing=True,
        dataloader_num_workers=4,
        group_by_length=True,
    )

    early_stopping = EarlyStoppingCallback(early_stopping_patience=5)
    data_collator = DataCollatorForSeq2Seq(global_tokenizer, padding=True, pad_to_multiple_of=8)

    trainer = Trainer(
        model=model,
        args=args,
        train_dataset=train_ds,
        eval_dataset=val_ds,
        data_collator=data_collator,
        callbacks=[early_stopping]
    )

    logger.info("🔥 Starting Training OpenCoder-1.5B...")
    trainer.train()

    logger.info("💾 Saving model...")
    trainer.save_model(OUTPUT_DIR)
    global_tokenizer.save_pretrained(OUTPUT_DIR)
    logger.info(f"✅ 完成！模型已保存至: {OUTPUT_DIR}")


if __name__ == "__main__":
    main()