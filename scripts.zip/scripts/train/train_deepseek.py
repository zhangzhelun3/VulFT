import os
import torch
import logging
import pandas as pd
import numpy as np
from datasets import Dataset
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training, TaskType
from transformers import (
    AutoTokenizer,
    AutoModelForCausalLM,
    TrainingArguments,
    Trainer,
    DataCollatorForSeq2Seq,
    BitsAndBytesConfig,
    EarlyStoppingCallback
)
from transformers.trainer_utils import get_last_checkpoint
from transformers.cache_utils import DynamicCache

# =========================================================
# 🩹 Monkey Patch: 修复 DeepSeek 兼容性问题
# =========================================================
if not hasattr(DynamicCache, "get_usable_length"):
    def get_usable_length(self, input_seq_length, layer_idx=None):
        return input_seq_length


    DynamicCache.get_usable_length = get_usable_length
    print("✅ Applied DynamicCache.get_usable_length monkey patch")

# ========== 1. 终极配置 ==========
MODEL_PATH = "/home/zhangzl/projects/LLM_fix/models/DeepSeek-Coder-V2-Lite-Instruct/"
OUTPUT_DIR = "/home/zhangzl/projects/LLM_fix/outputs/DeepSeek-V2-Lite-Final"
TRAIN_DATA_PATH = "/home/zhangzl/projects/CodeLlama/data/my_data/data_v3/train.csv"
VAL_DATA_PATH = "/home/zhangzl/projects/CodeLlama/data/my_data/data_v3/val.csv"

# 训练配置
NUM_EPOCHS = 2
MAX_LENGTH = 4096

# 【显存优化配置】
# BATCH_SIZE=16, Accum=2 -> 等效 BS=32
# 显存占用预计 45G-50G 左右，速度会比 BS=8 快很多
BATCH_SIZE = 8
GRAD_ACCUM_STEPS = 4
LEARNING_RATE = 1e-4

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# ========== 2. 数据处理 ==========
def process_data_deepseek(row, tokenizer):
    sys_msg = (
        "You are an expert vulnerability repair system. "
        "The input code contains one or more segments marked with <MODIFY_HERE>. "
        "Your task is to output the correct fixed code for EACH <MODIFY_HERE> segment, in order. "
        "Wrap each fix in <S2SV_ModStart> and <S2SV_ModEnd> tags."
    )
    user_msg = f"Fix the marked bugs in the following code:\n\n{row['new_source']}\n"

    messages_input = [
        {"role": "system", "content": sys_msg},
        {"role": "user", "content": user_msg}
    ]
    input_text = tokenizer.apply_chat_template(messages_input, tokenize=False, add_generation_prompt=True)

    input_ids = tokenizer(input_text, add_special_tokens=False)["input_ids"]
    target_str = row['completion']
    target_ids = tokenizer(target_str, add_special_tokens=False)["input_ids"]

    eos_id = tokenizer.eos_token_id
    full_ids = input_ids + target_ids + [eos_id]

    if len(full_ids) > MAX_LENGTH:
        full_ids = full_ids[:MAX_LENGTH]

    input_ids_tensor = torch.tensor(full_ids, dtype=torch.long)
    labels = input_ids_tensor.clone()

    prompt_len = len(input_ids)
    if prompt_len > len(labels):
        prompt_len = len(labels)
    labels[:prompt_len] = -100

    return {
        "input_ids": input_ids_tensor,
        "labels": labels,
        "attention_mask": torch.ones(len(full_ids), dtype=torch.long)
    }


# ========== 主程序 ==========
def main():
    logger.info("🚀 Loading Tokenizer...")
    tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH, trust_remote_code=True)

    tokenizer.padding_side = "right"
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    SPECIAL_TOKENS = ["<MODIFY_HERE>", "</MODIFY_HERE>", "<S2SV_ModStart>", "<S2SV_ModEnd>"]
    num_added = tokenizer.add_tokens(SPECIAL_TOKENS)
    logger.info(f"已添加 {num_added} 个特殊 Token")

    def load_ds(path):
        df = pd.read_csv(path)
        df = df[df['target'].str.contains("<S2SV_ModStart>", na=False)]
        df['completion'] = df['target']
        return Dataset.from_pandas(df.dropna(subset=['completion']))

    train_ds = load_ds(TRAIN_DATA_PATH)
    val_ds = load_ds(VAL_DATA_PATH)

    fn = lambda x: process_data_deepseek(x, tokenizer)
    logger.info("⏳ Processing data (num_proc=1)...")
    train_ds = train_ds.map(fn, remove_columns=train_ds.column_names, num_proc=1)
    val_ds = val_ds.map(fn, remove_columns=val_ds.column_names, num_proc=1)

    # 4-bit 量化配置
    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_compute_dtype=torch.bfloat16,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_use_double_quant=True
    )

    logger.info("🚀 Loading Model (DeepSeek MoE, 4-bit)...")
    try:
        model = AutoModelForCausalLM.from_pretrained(
            MODEL_PATH,
            quantization_config=bnb_config,
            trust_remote_code=True,
            device_map="auto",
            attn_implementation="flash_attention_2"
        )
        logger.info("✅ Flash Attention 2 enabled.")
    except Exception as e:
        logger.warning(f"⚠️ FA2 failed, using default: {e}")
        model = AutoModelForCausalLM.from_pretrained(
            MODEL_PATH,
            quantization_config=bnb_config,
            trust_remote_code=True,
            device_map="auto"
        )

    # 【关键修复】强制禁用 use_cache，彻底解决 Evaluation 时的 size mismatch 报错
    model.config.use_cache = False

    model.resize_token_embeddings(len(tokenizer))
    model = prepare_model_for_kbit_training(model)

    # LoRA 配置
    peft_config = LoraConfig(
        r=8,
        lora_alpha=16,
        target_modules=["q_proj", "v_proj"],
        modules_to_save=["embed_tokens", "lm_head"],
        lora_dropout=0.05,
        bias="none",
        task_type=TaskType.CAUSAL_LM
    )
    model = get_peft_model(model, peft_config)
    model.print_trainable_parameters()

    # Trainer 配置
    args = TrainingArguments(
        output_dir=OUTPUT_DIR,
        overwrite_output_dir=False,  # 设为 False 以支持断点续训
        per_device_train_batch_size=BATCH_SIZE,  # 16
        gradient_accumulation_steps=GRAD_ACCUM_STEPS,  # 2
        learning_rate=LEARNING_RATE,
        num_train_epochs=NUM_EPOCHS,

        warmup_steps=150,
        lr_scheduler_type="cosine",

        # 评测设置
        eval_strategy="steps",
        eval_steps=400,  # 改为 100 步评测一次，方便您更快看到 Loss 变化
        save_strategy="steps",
        save_steps=400,
        save_total_limit=2,
        load_best_model_at_end=True,
        metric_for_best_model="loss",
        greater_is_better=False,

        bf16=True,
        logging_steps=10,
        optim="paged_adamw_32bit",
        report_to="none",
        gradient_checkpointing=True,
        dataloader_num_workers=8,
        group_by_length=True,
    )

    early_stopping = EarlyStoppingCallback(early_stopping_patience=3)
    data_collator = DataCollatorForSeq2Seq(tokenizer, padding=True, pad_to_multiple_of=8)

    trainer = Trainer(
        model=model,
        args=args,
        train_dataset=train_ds,
        eval_dataset=val_ds,
        data_collator=data_collator,
        callbacks=[early_stopping]
    )

    # 自动断点续训逻辑
    checkpoint = None
    if os.path.isdir(OUTPUT_DIR):
        last_checkpoint = get_last_checkpoint(OUTPUT_DIR)
        if last_checkpoint is not None:
            checkpoint = last_checkpoint
            logger.info(f"🔄 Resuming training from: {checkpoint}")

    logger.info("🔥 Starting Training DeepSeek...")
    trainer.train(resume_from_checkpoint=checkpoint)

    logger.info("💾 Saving final model...")
    trainer.save_model(OUTPUT_DIR)
    tokenizer.save_pretrained(OUTPUT_DIR)


if __name__ == "__main__":
    main()