import os
import torch
import logging
import pandas as pd
import numpy as np
from datasets import Dataset
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training, TaskType
from transformers import (
    AutoTokenizer,
    AutoModelForCausalLM,
    TrainingArguments,
    Trainer,
    DataCollatorForSeq2Seq,
    BitsAndBytesConfig,
    EarlyStoppingCallback
)

# ========== 1. 终极配置 ==========
MODEL_PATH = "/home/zhangzl/projects/LLM_fix/models/Qwen2.5-Coder-7B-Instruct/"
OUTPUT_DIR = "/home/zhangzl/projects/LLM_fix/outputs/Qwen2.5-7B-Fix"
TRAIN_DATA_PATH = "/home/zhangzl/projects/CodeLlama/data/my_data/data_v3/train.csv"
VAL_DATA_PATH = "/home/zhangzl/projects/CodeLlama/data/my_data/data_v3/val.csv"

# 训练参数
NUM_EPOCHS = 3
MAX_LENGTH = 4096  # 保持 4096 防止截断，显存够就不要降
BATCH_SIZE = 4  # A100 推荐配置
GRAD_ACCUM_STEPS = 8  # 等效 BS=32
LEARNING_RATE = 1e-4

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# ========== 2. 数据处理 (防御性编程版) ==========
def process_data_qwen(row, tokenizer):
    # System Prompt 明确任务
    sys_msg = (
        "You are a helpful coding assistant specialized in fixing bugs. "
        "The input code contains segments marked with <MODIFY_HERE>. "
        "Your task is to output the correct fixed code for EACH <MODIFY_HERE> segment, in order. "
        "Wrap each fix in <S2SV_ModStart> and <S2SV_ModEnd> tags."
    )
    user_msg = f"The following code contains bugs:\n{row['new_source']}\n\nRepair the bugs."

    # 1. 生成 Prompt 文本 (System + User + Assistant引导)
    messages_input = [
        {"role": "system", "content": sys_msg},
        {"role": "user", "content": user_msg}
    ]
    # Qwen 的 chat template 会自动处理 <|im_start|> 等
    input_text = tokenizer.apply_chat_template(messages_input, tokenize=False, add_generation_prompt=True)

    # 2. Tokenize Prompt (不加特殊 Token，防止双重 BOS)
    input_ids = tokenizer(input_text, add_special_tokens=False)["input_ids"]

    # 3. Tokenize Target (手动处理，防止被切碎)
    target_str = row['completion']
    target_ids = tokenizer(target_str, add_special_tokens=False)["input_ids"]

    # 4. 拼接 + 加上 EOS
    eos_id = tokenizer.eos_token_id
    full_ids = input_ids + target_ids + [eos_id]

    # 5. 截断
    if len(full_ids) > MAX_LENGTH:
        full_ids = full_ids[:MAX_LENGTH]

    input_ids_tensor = torch.tensor(full_ids, dtype=torch.long)
    labels = input_ids_tensor.clone()

    # 6. Mask Prompt (核心：只训练回答部分)
    prompt_len = len(input_ids)
    if prompt_len > len(labels):
        prompt_len = len(labels)
    labels[:prompt_len] = -100

    return {
        "input_ids": input_ids_tensor,
        "labels": labels,
        "attention_mask": torch.ones(len(full_ids), dtype=torch.long)
    }


# ========== 主程序 ==========
def main():
    logger.info("🚀 Loading Tokenizer...")
    tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH, trust_remote_code=True)

    # 【检查点1】Padding Side 必须为 Right (对于训练生成式模型)
    tokenizer.padding_side = "right"
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    # 【检查点2】添加特殊 Token
    SPECIAL_TOKENS = ["<MODIFY_HERE>", "</MODIFY_HERE>", "<S2SV_ModStart>", "<S2SV_ModEnd>"]
    num_added = tokenizer.add_tokens(SPECIAL_TOKENS)
    logger.info(f"已添加 {num_added} 个特殊 Token")

    # 2. 数据加载
    def load_ds(path):
        df = pd.read_csv(path)
        df = df[df['target'].str.contains("<S2SV_ModStart>", na=False)]
        df['completion'] = df['target']
        return Dataset.from_pandas(df.dropna(subset=['completion']))

    train_ds = load_ds(TRAIN_DATA_PATH)
    val_ds = load_ds(VAL_DATA_PATH)

    # 【检查点3】单进程处理，保护特殊 Token
    fn = lambda x: process_data_qwen(x, tokenizer)
    logger.info("⏳ Processing data (num_proc=1)...")
    train_ds = train_ds.map(fn, remove_columns=train_ds.column_names, num_proc=1)
    val_ds = val_ds.map(fn, remove_columns=val_ds.column_names, num_proc=1)

    # 3. 模型加载 (4-bit QLoRA)
    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_compute_dtype=torch.bfloat16,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_use_double_quant=True
    )

    logger.info("🚀 Loading Model (4-bit)...")
    model = AutoModelForCausalLM.from_pretrained(
        MODEL_PATH,
        quantization_config=bnb_config,
        trust_remote_code=True,
        device_map="auto"
    )

    # 调整 Embedding 大小以适应新 Token
    model.resize_token_embeddings(len(tokenizer))

    # 4. LoRA 配置 (已修改为极速版)
    model = prepare_model_for_kbit_training(model)

    peft_config = LoraConfig(
        # 【修改点】Rank 降为 8
        r=8,
        lora_alpha=16,  # alpha 通常设为 r 的 2 倍
        # 【修改点】只训练核心 Attention 层，大幅减少计算量
        target_modules=["q_proj", "v_proj"],
        # 【必须保留】训练词表头，否则新 Token 学不会
        modules_to_save=["embed_tokens", "lm_head"],
        lora_dropout=0.05,
        bias="none",
        task_type="CAUSAL_LM"
    )
    model = get_peft_model(model, peft_config)
    model.print_trainable_parameters()

    # 5. Trainer 配置
    args = TrainingArguments(
        output_dir=OUTPUT_DIR,
        overwrite_output_dir=True,
        per_device_train_batch_size=BATCH_SIZE,
        gradient_accumulation_steps=GRAD_ACCUM_STEPS,
        learning_rate=LEARNING_RATE,
        num_train_epochs=NUM_EPOCHS,

        warmup_steps=100,
        lr_scheduler_type="cosine",

        eval_strategy="steps",
        eval_steps=500,
        save_strategy="steps",
        save_steps=500,
        save_total_limit=2,
        load_best_model_at_end=True,
        metric_for_best_model="loss",
        greater_is_better=False,

        bf16=True,
        logging_steps=10,
        optim="paged_adamw_32bit",
        report_to="none",
        gradient_checkpointing=True,
        dataloader_num_workers=8,
        group_by_length=True,
    )

    early_stopping = EarlyStoppingCallback(early_stopping_patience=3)
    data_collator = DataCollatorForSeq2Seq(tokenizer, padding=True, pad_to_multiple_of=8)

    # 6. 训练
    trainer = Trainer(
        model=model,
        args=args,
        train_dataset=train_ds,
        eval_dataset=val_ds,
        data_collator=data_collator,
        callbacks=[early_stopping]
    )

    logger.info("🔥 Starting Training Qwen2.5 (Fast Mode)...")
    trainer.train()

    logger.info("💾 Saving model...")
    trainer.save_model(OUTPUT_DIR)
    tokenizer.save_pretrained(OUTPUT_DIR)


if __name__ == "__main__":
    main()