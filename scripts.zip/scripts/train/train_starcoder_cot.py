import os
import torch
import logging
import pandas as pd
import numpy as np
from datasets import Dataset
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training, TaskType
from transformers import (
    AutoTokenizer,
    AutoModelForCausalLM,
    TrainingArguments,
    Trainer,
    DataCollatorForSeq2Seq,
    BitsAndBytesConfig,
    EarlyStoppingCallback
)

# ========== 1. 终极配置 ==========
MODEL_PATH = "/home/zhangzl/projects/LLM_fix/models/StarCoder2-15B-Instruct/"
OUTPUT_DIR = "/home/zhangzl/projects/LLM_fix/outputs/StarCoder2-15B-Fix-CoT"  # 修改了输出目录
TRAIN_DATA_PATH = "/home/zhangzl/projects/LLM_fix/data/train_cot_cleaned.csv"
VAL_DATA_PATH = "/home/zhangzl/projects/LLM_fix/data/val_cot_cleaned.csv"

# 训练配置
NUM_EPOCHS = 3
MAX_LENGTH = 4096
BATCH_SIZE = 8
GRAD_ACCUM_STEPS = 4
LEARNING_RATE = 1e-4

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# ========== 2. 数据处理 ==========
def process_data_starcoder(row, tokenizer):
    # 【关键修改 1】：System Prompt 必须明确要求输出 <THOUGHT>，
    # 这样在算 Loss 时，模型才不会觉得 Prompt 和 Target 之间有逻辑冲突。
    sys_msg = (
        "You are an expert vulnerability repair system. "
        "The input code contains one or more segments marked with <MODIFY_HERE>.\n"
        "Before generating the code, you MUST engage in a continuous, logically flowing analysis "
        "to deduce the root cause and repair strategy. Enclose your analysis strictly within <THOUGHT> and </THOUGHT> tags.\n"
        "Finally, output ONLY the exact fixed code snippet wrapped strictly within <S2SV_ModStart> and <S2SV_ModEnd> tags."
    )
    user_msg = f"Fix the marked bugs in the following code:\n\n{row['new_source']}\n"

    prompt_text = f"### System:\n{sys_msg}\n\n### User:\n{user_msg}\n\n### Assistant:\n"

    input_ids = tokenizer(prompt_text, add_special_tokens=False)["input_ids"]
    target_str = row['completion']
    target_ids = tokenizer(target_str, add_special_tokens=False)["input_ids"]

    eos_id = tokenizer.eos_token_id
    full_ids = input_ids + target_ids + [eos_id]

    if len(full_ids) > MAX_LENGTH:
        full_ids = full_ids[:MAX_LENGTH]

    input_ids_tensor = torch.tensor(full_ids, dtype=torch.long)
    labels = input_ids_tensor.clone()

    # Mask Prompt: 只对 Target（也就是包含 THOUGHT 和 代码 的部分）计算 Loss
    prompt_len = len(input_ids)
    if prompt_len > len(labels):
        prompt_len = len(labels)
    labels[:prompt_len] = -100

    return {
        "input_ids": input_ids_tensor,
        "labels": labels,
        "attention_mask": torch.ones(len(full_ids), dtype=torch.long)
    }


# ========== 主程序 ==========
def main():
    logger.info("🚀 Loading Tokenizer...")
    tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH, trust_remote_code=True)

    tokenizer.padding_side = "right"
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    # 【关键修改 2】：必须把 THOUGHT 的标签也加进特殊 Token 里，防止被切碎
    SPECIAL_TOKENS = ["<MODIFY_HERE>", "</MODIFY_HERE>", "<S2SV_ModStart>", "<S2SV_ModEnd>", "<THOUGHT>", "</THOUGHT>"]
    num_added = tokenizer.add_tokens(SPECIAL_TOKENS)
    logger.info(f"已添加 {num_added} 个特殊 Token")

    # 【关键修改 3】：稳健的数据加载逻辑（处理无表头）
    # 【关键修改 3】：稳健的数据加载逻辑（适配 new_source, target, cot_completion）
    def load_ds(path, is_train=False):
        try:
            df = pd.read_csv(path)
            # 检查是否有我们要的关键列
            if 'new_source' not in df.columns or 'cot_completion' not in df.columns:
                raise ValueError("No standard headers found")
        except Exception:
            logger.info(f"⚠️ {path} 未检测到标准表头，正在手动注入表头...")
            # 针对你指出的 3 列无表头情况：new_source, target, cot_completion
            temp_df = pd.read_csv(path, header=None)
            if temp_df.shape[1] == 3:
                temp_df.columns = ['new_source', 'target', 'cot_completion']
            else:
                raise ValueError(f"无法自动推断列名，该 CSV 有 {temp_df.shape[1]} 列！预期是 3 列。")
            df = temp_df

        # 过滤无效行：必须包含代码修复起始符
        df = df[df['cot_completion'].str.contains("<S2SV_ModStart>", na=False)]

        # 验证是否真的包含思考过程
        cot_count = df['cot_completion'].str.contains("<THOUGHT>").sum()
        logger.info(f"数据集 {path} 中包含 <THOUGHT> 的样本数为: {cot_count} / {len(df)}")

        # 【最核心的一步】：把 cot_completion 赋值给 completion
        # 因为上面的 process_data_starcoder 函数认准了 'completion' 这一列作为最终目标
        df['completion'] = df['cot_completion']

        return Dataset.from_pandas(df.dropna(subset=['completion']))

    train_ds = load_ds(TRAIN_DATA_PATH, is_train=True)
    val_ds = load_ds(VAL_DATA_PATH, is_train=False)

    fn = lambda x: process_data_starcoder(x, tokenizer)
    logger.info("⏳ Processing data (num_proc=1)...")
    train_ds = train_ds.map(fn, remove_columns=train_ds.column_names, num_proc=1)
    val_ds = val_ds.map(fn, remove_columns=val_ds.column_names, num_proc=1)

    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_compute_dtype=torch.bfloat16,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_use_double_quant=True
    )

    logger.info("🚀 Loading Model (15B, 4-bit)...")
    try:
        model = AutoModelForCausalLM.from_pretrained(
            MODEL_PATH, quantization_config=bnb_config, trust_remote_code=True,
            device_map="auto", attn_implementation="flash_attention_2"
        )
        logger.info("✅ Flash Attention 2 enabled.")
    except Exception as e:
        logger.warning(f"⚠️ Flash Attention 2 loading failed ({str(e)}).")
        model = AutoModelForCausalLM.from_pretrained(
            MODEL_PATH, quantization_config=bnb_config, trust_remote_code=True, device_map="auto"
        )

    model.resize_token_embeddings(len(tokenizer))

    model = prepare_model_for_kbit_training(model)
    peft_config = LoraConfig(
        r=4,
        lora_alpha=16,
        target_modules="all-linear",
        modules_to_save=["embed_tokens", "lm_head"],
        lora_dropout=0.05,
        bias="none",
        task_type=TaskType.CAUSAL_LM
    )
    model = get_peft_model(model, peft_config)
    model.print_trainable_parameters()

    args = TrainingArguments(
        output_dir=OUTPUT_DIR,
        overwrite_output_dir=True,
        per_device_train_batch_size=BATCH_SIZE,
        gradient_accumulation_steps=GRAD_ACCUM_STEPS,
        learning_rate=LEARNING_RATE,
        num_train_epochs=NUM_EPOCHS,
        warmup_steps=150,
        lr_scheduler_type="cosine",
        eval_strategy="steps",
        eval_steps=500,
        save_strategy="steps",
        save_steps=500,
        save_total_limit=2,
        load_best_model_at_end=True,
        metric_for_best_model="loss",
        greater_is_better=False,
        bf16=True,
        logging_steps=10,
        optim="paged_adamw_32bit",
        report_to="none",
        gradient_checkpointing=True,
        dataloader_num_workers=8,
        group_by_length=True,
    )

    early_stopping = EarlyStoppingCallback(early_stopping_patience=3)
    data_collator = DataCollatorForSeq2Seq(tokenizer, padding=True, pad_to_multiple_of=8)

    trainer = Trainer(
        model=model, args=args, train_dataset=train_ds, eval_dataset=val_ds,
        data_collator=data_collator, callbacks=[early_stopping]
    )

    logger.info("🔥 Starting Training StarCoder2-15B with CoT...")
    trainer.train()

    logger.info("💾 Saving model...")
    trainer.save_model(OUTPUT_DIR)
    tokenizer.save_pretrained(OUTPUT_DIR)


if __name__ == "__main__":
    main()