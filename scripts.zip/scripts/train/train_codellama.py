import os
import torch
import logging
import pandas as pd
from datasets import Dataset
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
from transformers import (
    AutoTokenizer,
    AutoModelForCausalLM,
    TrainingArguments,
    Trainer,
    DataCollatorForSeq2Seq,
    BitsAndBytesConfig,
    EarlyStoppingCallback
)

# ==========================================
# ⚙️ 1. 配置区域
# ==========================================
MODEL_PATH = "/home/zhangzl/projects/LLM_fix/models/CodeLlama-7b-Instruct-hf"
OUTPUT_DIR = "/home/zhangzl/projects/LLM_fix/outputs/CodeLlama-7b-Fix-Stable"

TRAIN_DATA_PATH = "/home/zhangzl/projects/CodeLlama/data/my_data/data_v3/train.csv"
VAL_DATA_PATH = "/home/zhangzl/projects/CodeLlama/data/my_data/data_v3/val.csv"

# 训练参数
NUM_EPOCHS = 2
MAX_LENGTH = 2048
BATCH_SIZE = 8
GRAD_ACCUM_STEPS = 4
LEARNING_RATE = 2e-4  # 恢复正常的 QLoRA 学习率，因为我们不再训练 lm_head 了

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# ==========================================
# 🛠️ 2. 数据处理 (不添加特殊 Token 版)
# ==========================================
def process_data_codellama(row, tokenizer):
    sys_msg = (
        "You are a helpful coding assistant specialized in fixing bugs. "
        "The input code contains segments marked with <MODIFY_HERE>. "
        "Your task is to output the correct fixed code for EACH <MODIFY_HERE> segment, in order. "
        "Wrap each fix in <S2SV_ModStart> and <S2SV_ModEnd> tags."
    )
    user_msg = f"The following code contains bugs:\n{row['new_source']}\n\nRepair the bugs."

    prompt_text = f"[INST] <<SYS>>\n{sys_msg}\n<</SYS>>\n\n{user_msg} [/INST]"

    # ⚠️ 关键修改：add_special_tokens=True 会自动加 BOS (<s>)
    # 此时不需要 tokenizer.add_tokens，它会把 tag 当作普通字符串处理
    input_ids = tokenizer(prompt_text, add_special_tokens=True)["input_ids"]

    target_str = row['completion']
    target_ids = tokenizer(target_str, add_special_tokens=False)["input_ids"]

    # 拼接: [Prompt] [Answer] [EOS]
    eos_id = tokenizer.eos_token_id
    full_ids = input_ids + target_ids + [eos_id]

    # 截断
    if len(full_ids) > MAX_LENGTH:
        full_ids = full_ids[:MAX_LENGTH]

    input_ids_tensor = torch.tensor(full_ids, dtype=torch.long)
    labels = input_ids_tensor.clone()

    # Masking: Prompt 部分不计算 loss
    prompt_len = len(input_ids)
    if prompt_len > len(labels):
        prompt_len = len(labels)
    labels[:prompt_len] = -100

    return {
        "input_ids": input_ids_tensor,
        "labels": labels,
        "attention_mask": torch.ones(len(full_ids), dtype=torch.long)
    }


# ==========================================
# 🚀 3. 主程序
# ==========================================
def main():
    logger.info("🚀 Loading Tokenizer...")
    tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH, trust_remote_code=True)

    # Padding 设置
    tokenizer.padding_side = "right"
    if tokenizer.pad_token is None:
        if tokenizer.unk_token_id is not None:
            tokenizer.pad_token = tokenizer.unk_token
            tokenizer.pad_token_id = tokenizer.unk_token_id
        else:
            tokenizer.pad_token = tokenizer.eos_token
            tokenizer.pad_token_id = tokenizer.eos_token_id

    # 🛑【核心改动 1】不要添加特殊 Token！
    # 删除了 tokenizer.add_tokens(...)
    # 这样词表大小保持 32000 不变，不需要 resize model

    # 加载数据
    def load_ds(path):
        df = pd.read_csv(path).dropna(subset=['target', 'new_source'])
        # 简单清洗
        df = df[df['target'].str.contains("<S2SV_ModStart>", na=False)]
        df['completion'] = df['target']
        return Dataset.from_pandas(df)

    train_ds = load_ds(TRAIN_DATA_PATH)
    val_ds = load_ds(VAL_DATA_PATH)

    logger.info("⏳ Processing data...")
    fn = lambda x: process_data_codellama(x, tokenizer)
    train_ds = train_ds.map(fn, remove_columns=train_ds.column_names, num_proc=1)
    val_ds = val_ds.map(fn, remove_columns=val_ds.column_names, num_proc=1)

    # 模型加载
    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_compute_dtype=torch.bfloat16,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_use_double_quant=True
    )

    logger.info("🚀 Loading Model (4-bit)...")
    model = AutoModelForCausalLM.from_pretrained(
        MODEL_PATH,
        quantization_config=bnb_config,
        trust_remote_code=True,
        device_map="auto",
        attn_implementation="eager"
    )

    model.config.use_cache = False

    # 🛑【核心改动 2】不要 Resize Embedding
    # model.resize_token_embeddings(len(tokenizer)) <--- 这一行删掉

    # LoRA 配置
    model = prepare_model_for_kbit_training(model)
    peft_config = LoraConfig(
        r=16,
        lora_alpha=32,
        target_modules=["q_proj", "v_proj"],
        # 🛑【核心改动 3】不要把 embed_tokens 和 lm_head 加入 modules_to_save
        # modules_to_save=["embed_tokens", "lm_head"], <--- 这一行删掉
        lora_dropout=0.05,
        bias="none",
        task_type="CAUSAL_LM"
    )
    model = get_peft_model(model, peft_config)

    # 打印参数：此时 trainable params 应该非常小（只有几百万），这是对的！
    model.print_trainable_parameters()

    # 训练参数
    args = TrainingArguments(
        output_dir=OUTPUT_DIR,
        overwrite_output_dir=True,
        per_device_train_batch_size=BATCH_SIZE,
        gradient_accumulation_steps=GRAD_ACCUM_STEPS,
        num_train_epochs=NUM_EPOCHS,
        learning_rate=LEARNING_RATE,
        warmup_steps=100,
        lr_scheduler_type="cosine",

        # 稳定性
        max_grad_norm=0.3,  # 压得更低一点
        bf16=True,
        bf16_full_eval=True,

        # Eval
        eval_strategy="steps",
        eval_steps=400,
        save_strategy="steps",
        save_steps=400,
        save_total_limit=2,
        load_best_model_at_end=True,
        metric_for_best_model="loss",

        logging_steps=10,
        report_to="none",
        gradient_checkpointing=True,
        group_by_length=True,
        dataloader_num_workers=4
    )

    data_collator = DataCollatorForSeq2Seq(tokenizer, padding=True, pad_to_multiple_of=8)

    trainer = Trainer(
        model=model,
        args=args,
        train_dataset=train_ds,
        eval_dataset=val_ds,
        data_collator=data_collator,
        callbacks=[EarlyStoppingCallback(early_stopping_patience=5)]
    )

    logger.info("🔥 Starting Training (No-Embedding-Resize Mode)...")
    trainer.train()

    logger.info(f"💾 Saving model to {OUTPUT_DIR}...")
    trainer.save_model(OUTPUT_DIR)
    tokenizer.save_pretrained(OUTPUT_DIR)
    logger.info("✅ Training Complete!")


if __name__ == "__main__":
    main()